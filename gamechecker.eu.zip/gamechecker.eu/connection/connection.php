<?php
$host_name = 'localhost'; //nome dell'host
$db_user = 'alezag74_gamechecker'; //utente del server
$db_password = 'zaga2004zz#'; //password dell'utente

$connection = mysqli_connect($host_name, $db_user, $db_password); //connessione all host
?>